from django.apps import AppConfig


class TestexamConfig(AppConfig):
    name = 'testexam'
