from django.db import models

# Create your models here.

class Quiz:
    textQuestion : str
    numericQuestion : str
    binaryQuestion : str
